<?php

//Isi USER-AGENT Sesuai Data Kalian
$user = 'Mozilla/5.0 (Linux; Android 8.0.0; SM-A520F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.56 Mobile Safari/537.36';

//Isi Cookie Sesuai Data Kalian
$cookie = 'captcha=recaptchav2; csrf_cookie_name=751d8c90a2e081e8db33d40ed0750ebd; ci_session=58478262f6baf13657e121dc1c3f44dc8dfd9c5d; _data_cpc=1-2_121-1_190-1_219-1_220-2_333-3_346-1; useragent=TW96aWxsYS81LjAgKExpbnV4OyBBbmRyb2lkIDguMC4wOyBTTS1BNTIwRikgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzk0LjAuNDYwNi41NiBNb2JpbGUgU2FmYXJpLzUzNy4zNg%3D%3D';